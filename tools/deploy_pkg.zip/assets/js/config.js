// =========================================================
// TOUCHAD CONFIGURATION
// Security: Do not commit this file if it contains real keys.
// =========================================================

const TOUCH_CONFIG = {
  // Kakao Maps JavaScript API Key
  // Type: JavaScript Key (NOT REST API Key)
  // Required capabilities: libraries=visualization
  KAKAO_API_KEY: "2bd91dd5ed75050e78640aaee77b9b6b"
};
